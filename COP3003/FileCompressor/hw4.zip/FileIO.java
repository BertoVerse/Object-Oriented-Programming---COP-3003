import java.io.*;
import java.util.*;

class FileStats{
	private Scanner input;
	private ArrayList <String> wordList=new ArrayList<String>();
	private HashSet <String> wordSet=new HashSet<String>();
	private ArrayList <Entry<String>> entryList=new ArrayList<Entry<String>>();
	private Map <String, Character> dictionary=new TreeMap<String, Character>();

	private class Entry <T> implements Comparable<Entry<T>>{
		public T word;
		public int frequency;
		public Entry(T word, int f){
			this.word=word;
			frequency=f;
		}
		public int compareTo(Entry<T> e){
			// insert your code
		}
	}

	public FileStats(String path) {

		/* insert your code here */
		/* open the file, named path */


		count();
	}

	/*
	 * This method is supposed to
	 * 1. find the frequency of each word in the file.
	 * 2. display the four most frequent words and their frequencies.
	 * 3. construct the dictionary that four key-value pairs. The keys
	 *    are the most frequent words and the values are the characters,
	 *    used to represent the words.
	 */
	private void count() {
		/* insert your code here */
	}

	public Map<String, Character> getDictionary(){
		return dictionary;
	}
}

class FileCompressor{
	public static void compress(String src, String dest,
			Map<String, Character> dictionary){

		/* insert your code here */

	}

	public static void decompress(String src, String dest,
			Map<Character, String> dictionary){

		/* insert your code here */

	}
}

public class FileIO {
	public static void main(String args[]) throws IOException{
		FileStats fs=new FileStats("basketball.txt");
		fs.printDictionary();

		Map <String, Character> m1=fs.getDictionary();
		FileCompressor.compress("basketball.txt", "compressed.txt",m1);

		/* insert your code here */
			/* create another dictionary for decompress and name it m2 */

		FileCompressor.decompress("compressed.txt", "decompressed.txt",m2);
	}
}
